import React from 'react'

const Component = () => <div>
    value
  <input type='text' >
  <button class='button'>button</button>
</div>
