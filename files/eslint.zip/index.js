    const error = 'err'

import Eslint from 'eslint'

var security = new Buffer(5);

let a = 'I \u2661 JavaScript!'
let a = ''

console.log('log ${error}')

console.log(unknown)

const fn = (a,b,  c,d)=>{}

