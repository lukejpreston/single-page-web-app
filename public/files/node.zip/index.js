var greeter = {
  greet: function (message) {
    console.log(message)
  }
}

greeter.greet('hello')
